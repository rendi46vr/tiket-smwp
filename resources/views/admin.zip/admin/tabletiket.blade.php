<table class="table ft ftc table-responsive-w-100 table-bordered" id="dataCetak">
    <thead>
        <tr>
            <th>No</th>
            <th>Tanggal input</th>
            <th> Berlaku</th>
            <th>Jenis tiket</th>
            <th>Qty</th>
            <th>Unduh</th>
        </tr>
    </thead>
    <tbody>
        @foreach($tiket as $t)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$t->created_at}}</td>
            <td>{{$t->tgl == '' ? "Rabu,Kamis & Jum'at" : $t->tgl}}</td>
            <td>{{$t->tiket_id == 1 ? "Regular Day" : "Premiu Day"}}</td>
            <td>{{$t->qty}}</td>
            <td> <a href="{{url('download/'.$t->id)}}"> <i class="fa fa-download text-success" aria-hidden="true"></i></a></td>
        </tr>
        @endforeach
    </tbody>
</table>


{!!$pagination!!}